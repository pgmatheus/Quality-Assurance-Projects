/*
*
*
*       Complete the API routing below
*       
*       
*/

'use strict';
const mongoose = require('mongoose');
mongoose.connect(process.env.DB_URI,{useNewUrlParser: true});

const Book = new mongoose.Schema({
  title: String,
  commentcount: Number,
  comments: [String]
});

const book = mongoose.model('book',Book)


module.exports = function (app) {

  app.route('/api/books')
    .get(function (req, res){
      //response will be array of book objects
      //json res format: [{"_id": bookid, "title": book_title, "commentcount": num_of_comments },...]
      book.find({})
        .exec((err,doc) => {
          if (err) console.log(err)
          else{
            res.json(doc)
          }
        })
    })
    
    .post(function (req, res){
      let title = req.body.title;
      
      if (title == '' || title == undefined){
        res.send('missing required field title')
      }
      else{
        const a = new book({comments: [], title: title,commentcount: 0})
        a.save(function(err,doc) {
          if (err) console.log(err)
          else{
            res.send({_id: doc._id,title:doc.title})
          }
        })
      }
    })

    .delete(function(req, res){
      //if successful response will be 'complete delete successful'
      book.deleteMany({})
        .exec((err,doc)=> {
          if (err) console.log(err)
          res.send('complete delete successful')
        })
       
    });

  app.route('/api/books/:id')
    .get(function (req, res){
      let bookid = req.params.id;
      console.log(req.params.id)
    
      //json res format: {"_id": bookid, "title": book_title, "comments": [comment,comment,...]}
      book.find({_id:bookid})
        .exec((err,doc) => {
          console.log('inicio')
          // if (doc[0] != undefined){doc = doc[0]}
          

          // if (doc[0] != undefined){doc = doc[0]}
          if (err) console.log(err)
            
            if (doc == undefined){
              res.json('no book exists')
            }
            else if(doc[0] == undefined){res.json('no book exists')}
            else{
              //res.json({comments: doc[0].comments,_id: doc[0]._id, title: doc[0].title, commentcount: doc[0].commentcount, __v: doc[0].__v})
              if (doc[0] != undefined){doc = doc[0]}
              res.json({comments: doc.comments,_id: doc._id, title: doc.title, commentcount: doc.commentcount, __v: doc.__v})
            }
            





        })

    })
    
    .post(function(req, res){
      let bookid = req.params.id;
      let comment = req.body.comment;
      //if (comment == '' || comment == undefined || comment == []){
      //  res.send('missing required field comment');
      //}
      //if (false)
      //else{

        book.find({_id: bookid})
        .exec((err, doc) => {
          if (err) console.log(err)
        
          if (doc == undefined){res.send('no book exists')}
          else if(doc[0] == undefined){res.send('no book exists')}
         else{
          if (comment == '' || comment == undefined || comment == []){res.send('missing required field comment');
          }else{
           if (doc[0] != undefined){doc = doc[0]}
           doc.commentcount++;
           if (doc.comments == undefined){doc.comments = comment}
           else{doc.comments = doc.comments.concat(comment);}
           
          book.findOneAndUpdate({_id: doc._id}, {commentcount:doc.commentcount, comments: doc.comments}, {new: true})
          .exec((err,doc1) => {
            if (err) console.log(err)

            res.json(doc1)              
          })
          }          
        }

        })
      //}
    })
    
    .delete(function(req, res){

      let bookid = req.params.id;

      //if successful response will be 'delete successful'
        book.findOneAndDelete({_id:bookid})
          .exec((err,doc) => {
            if (err) console.log(err)
            if (doc == undefined){    
              res.json('no book exists');
            }
            else{
              res.json('delete successful');
            } 
        
        
          })




    });
  
};
